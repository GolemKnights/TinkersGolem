package dev.xkmc.modulargolems.content.modifier.immunes;

import dev.xkmc.l2library.base.effects.EffectUtil;
import dev.xkmc.modulargolems.content.core.StatFilterType;
import dev.xkmc.modulargolems.content.entity.common.AbstractGolemEntity;
import dev.xkmc.modulargolems.content.entity.common.GolemFlags;
import dev.xkmc.modulargolems.content.modifier.base.GolemModifier;
import dev.xkmc.modulargolems.init.advancement.GolemTriggers;
import dev.xkmc.modulargolems.init.data.MGConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import java.util.List;
import java.util.function.Consumer;

// 雷免
public class ThunderImmuneModifier extends GolemModifier {

	/**
	 * Fire resistance granted when struck by lightning, in ticks.
	 */
	public static final int FIRE_RESIST_TICKS = 200;

	public ThunderImmuneModifier() {
		super(StatFilterType.HEALTH, 2);
	}

	@Override
	public void onAttacked(AbstractGolemEntity<?, ?> entity, LivingAttackEvent event, int level) {
		if (level <= 0) return;
		if (entity.isOnFire()) {
			// 灭火
			entity.clearFire();
		}
		if (event.getSource().is(DamageTypeTags.IS_LIGHTNING)) {
			event.setCanceled(true);
			EffectUtil.addEffect(entity, new MobEffectInstance(MobEffects.FIRE_RESISTANCE, FIRE_RESIST_TICKS), EffectUtil.AddReason.SELF, entity);
			entity.heal(MGConfig.COMMON.thunderHeal.get() * level);
			Player player = entity.getOwner();
			if (player instanceof ServerPlayer pl) {
				GolemTriggers.THUNDER.trigger(pl);
			}
		}
	}

	@Override
	public void onRegisterFlag(Consumer<GolemFlags> addFlag) {
		addFlag.accept(GolemFlags.THUNDER_IMMUNE);
	}

	public List<MutableComponent> getDetail(int v) {
		int heal = MGConfig.COMMON.thunderHeal.get() * v;
		var ctime = Component.literal("" + (FIRE_RESIST_TICKS / 20)).withStyle(ChatFormatting.AQUA);
		var cheal = Component.literal("" + heal).withStyle(ChatFormatting.AQUA);
		return List.of(Component.translatable(getDescriptionId() + ".desc", ctime, cheal).withStyle(ChatFormatting.GREEN));
	}

}
