package dev.xkmc.modulargolems.init.registrate;

import java.util.List;

import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import dev.xkmc.l2library.base.L2Registrate;
import dev.xkmc.l2screentracker.init.L2STTagGen;
import dev.xkmc.modulargolems.compat.materials.common.CompatManager;
import dev.xkmc.modulargolems.content.block.SimpleTableBlock;
import dev.xkmc.modulargolems.content.block.TableBlock;
import dev.xkmc.modulargolems.content.client.armor.GolemModelPaths;
import dev.xkmc.modulargolems.content.entity.dog.DogGolemEntity;
import dev.xkmc.modulargolems.content.entity.dog.DogGolemPartType;
import dev.xkmc.modulargolems.content.entity.humanoid.HumanoidGolemEntity;
import dev.xkmc.modulargolems.content.entity.humanoid.HumanoidGolemPartType;
import dev.xkmc.modulargolems.content.entity.metalgolem.MetalGolemEntity;
import dev.xkmc.modulargolems.content.entity.metalgolem.MetalGolemPartType;
import dev.xkmc.modulargolems.content.item.card.*;
import dev.xkmc.modulargolems.content.item.equipments.*;
import dev.xkmc.modulargolems.content.item.golem.GolemFacade;
import dev.xkmc.modulargolems.content.item.golem.GolemHolder;
import dev.xkmc.modulargolems.content.item.golem.GolemPart;
import dev.xkmc.modulargolems.content.item.ranged.*;
import dev.xkmc.modulargolems.content.item.upgrade.AddSlotTemplate;
import dev.xkmc.modulargolems.content.item.upgrade.SimpleUpgradeItem;
import dev.xkmc.modulargolems.content.item.wand.*;
import dev.xkmc.modulargolems.content.modifier.base.GolemModifier;
import dev.xkmc.modulargolems.init.ModularGolems;
import dev.xkmc.modulargolems.init.data.MGTagGen;
import dev.xkmc.modulargolems.init.material.GolemWeaponType;
import dev.xkmc.modulargolems.init.material.VanillaGolemWeaponMaterial;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraftforge.client.model.generators.ModelFile;

import java.util.function.Supplier;

import static dev.xkmc.modulargolems.init.ModularGolems.REGISTRATE;

@SuppressWarnings("removal")
public class GolemItems {

	public static final RegistryEntry<CreativeModeTab> ITEMS, UPGRADES, GOLEMS, PARTS;

	static {
		ITEMS = REGISTRATE.buildL2CreativeTab("golem_items", "Modular Golems - Items", b -> b
				.icon(GolemItems.GOLEM_TEMPLATE::asStack));
		UPGRADES = REGISTRATE.buildL2CreativeTab("golem_upgrades", "Modular Golems - Upgrades", b -> b
				.icon(GolemItems.RECYCLE::asStack));
		REGISTRATE.defaultCreativeTab(ITEMS.getKey());
	}

	public static final BlockEntry<TableBlock> TABLE;
	public static final BlockEntry<SimpleTableBlock> SIMPLE_TABLE;

	public static final ItemEntry<Item> GOLEM_TEMPLATE, EMPTY_UPGRADE;

	public static final ItemEntry<GolemPart<MetalGolemEntity, MetalGolemPartType>> GOLEM_BODY, GOLEM_ARM, GOLEM_LEGS;
	public static final ItemEntry<GolemHolder<MetalGolemEntity, MetalGolemPartType>> HOLDER_GOLEM;

	public static final ItemEntry<GolemPart<HumanoidGolemEntity, HumanoidGolemPartType>> HUMANOID_BODY, HUMANOID_ARMS, HUMANOID_LEGS;
	public static final ItemEntry<GolemHolder<HumanoidGolemEntity, HumanoidGolemPartType>> HOLDER_HUMANOID;

	public static final ItemEntry<GolemPart<DogGolemEntity, DogGolemPartType>> DOG_BODY, DOG_LEGS;
	public static final ItemEntry<GolemHolder<DogGolemEntity, DogGolemPartType>> HOLDER_DOG;

	public static final ItemEntry<SimpleUpgradeItem> FIRE_IMMUNE, THUNDER_IMMUNE, RECYCLE, DIAMOND, NETHERITE, QUARTZ,
			GOLD, ENCHANTED_GOLD, FLOAT, SPONGE, SWIM, PLAYER_IMMUNE, ENDER_SIGHT, BELL, SPEED, SLOW, WEAK, WITHER,
			EMERALD, PICKUP, PICKUP_MENDING, PICKUP_NO_DESTROY, TALENTED, CAULDRON, MOUNT_UPGRADE, SIZE_UPGRADE;

	public static final ItemEntry<RetrievalWandItem> RETRIEVAL_WAND, OMNI_RETRIVAL;
	public static final ItemEntry<CommandWandItem> COMMAND_WAND, OMNI_COMMAND;
	public static final ItemEntry<DispenseWand> DISPENSE_WAND, OMNI_DISPENSE;
	public static final ItemEntry<RiderWandItem> RIDER_WAND, OMNI_RIDER;
	public static final ItemEntry<SquadWandItem> SQUAD_WAND, OMNI_SQUAD;
	public static final ItemEntry<HostileWandItem> HOSTILE_WAND;

	public static final ItemEntry<MetalGolemArmorItem> GOLEMGUARD_HELMET, WINDSPIRIT_HELMET, BARBARICFLAMEVANGUARD_HELMET;
	public static final ItemEntry<MetalGolemArmorItem> GOLEMGUARD_CHESTPLATE, WINDSPIRIT_CHESTPLATE, BARBARICFLAMEVANGUARD_CHESTPLATE;
	public static final ItemEntry<MetalGolemArmorItem> GOLEMGUARD_SHINGUARD, WINDSPIRIT_SHINGUARD, BARBARICFLAMEVANGUARD_SHINGUARD;
	public static final ItemEntry<MetalGolemArmorItem> GOLEMGUARD_BOOTS;
	public static final ItemEntry<MetalGolemArmorItem> WINDSPIRIT_BOOTS;
	public static final ItemEntry<NetheriteBootItem> BARBARICFLAMEVANGUARD_BOOTS;
	public static final ItemEntry<MetalGolemWeaponItem>[][] METALGOLEM_WEAPON;
	public static final ItemEntry<MetalGolemBowItem> IRON_BOW;
	public static final ItemEntry<MetalGolemMechaBowItem> NETHERITE_BOW;
	public static final ItemEntry<SonicCannonItem> SONIC_CANNON;
	public static final ItemEntry<BeaconCannonItem> BEACON_CANNON;
	public static final ItemEntry<FlameThrowerItem> FLAME_THROWER;
	public static final ItemEntry<SlicingAxe> SLICING_AXE;
	public static final ItemEntry<MetalGolemBeaconItem> BEACON_BOOTS;
	public static final ItemEntry<ConfigCard>[] CARD;
	public static final ItemEntry<PathRecordCard> CARD_PATH;
	public static final ItemEntry<NameFilterCard> CARD_NAME;
	public static final ItemEntry<EntityTypeFilterCard> CARD_TYPE;
	public static final ItemEntry<UuidFilterCard> CARD_UUID;
	public static final ItemEntry<DefaultFilterCard> CARD_DEF;
	public static final ItemEntry<GolemFacade> FACADE;
	public static final ItemEntry<AddSlotTemplate> ADD_DIAMOND, ADD_NETHERITE;

	public static final ItemEntry<DogGolemArmorItem> DOG_ARMOR_IRON, DOG_ARMOR_GOLD, DOG_ARMOR_DIAMOND, DOG_ARMOR_NETHERITE;

	static {

		SIMPLE_TABLE = REGISTRATE.block("golem_workbench_simple", SimpleTableBlock::new)
				.initialProperties(() -> Blocks.ANVIL)
				.properties(p -> p.sound(SoundType.STONE))
				.blockstate((ctx, pvd) -> pvd.simpleBlock(ctx.get(), pvd.models()
						.getBuilder("block/" + ctx.getName())
						.parent(new ModelFile.UncheckedModelFile(pvd.modLoc("custom/table")))
						.texture("top", pvd.modLoc("block/simple_table_top"))
						.texture("middle", pvd.modLoc("block/simple_table_middle"))
						.texture("bottom", pvd.modLoc("block/simple_table_bottom"))
						.texture("particle", pvd.modLoc("block/simple_table_particle"))
				)).tag(BlockTags.MINEABLE_WITH_PICKAXE)
				.item().tag(L2STTagGen.QUICK_ACCESS_VANILLA).build()
				.register();

		TABLE = REGISTRATE.block("golem_workbench", TableBlock::new)
				.initialProperties(() -> Blocks.ANVIL)
				.blockstate((ctx, pvd) -> pvd.simpleBlock(ctx.get(), pvd.models()
						.getBuilder("block/" + ctx.getName())
						.parent(new ModelFile.UncheckedModelFile(pvd.modLoc("custom/table")))
						.texture("top", pvd.modLoc("block/table_top"))
						.texture("middle", pvd.modLoc("block/table_middle"))
						.texture("bottom", pvd.modLoc("block/table_bottom"))
						.texture("particle", pvd.modLoc("block/table_particle"))
				)).tag(BlockTags.MINEABLE_WITH_PICKAXE)
				.item().tag(L2STTagGen.QUICK_ACCESS_VANILLA).build()
				.register();

		GOLEM_TEMPLATE = REGISTRATE.item("metal_golem_template", Item::new).defaultModel().defaultLang().register();

		{
			RETRIEVAL_WAND = REGISTRATE.item("retrieval_wand", p -> new RetrievalWandItem(p.stacksTo(1), null))
					.model((ctx, pvd) -> pvd.handheld(ctx)).defaultLang().tag(MGTagGen.GOLEM_INTERACT).register();
			COMMAND_WAND = REGISTRATE.item("command_wand", p -> new CommandWandItem(p.stacksTo(1), null))
					.model((ctx, pvd) -> pvd.handheld(ctx)).defaultLang().tag(MGTagGen.GOLEM_INTERACT).register();
			DISPENSE_WAND = REGISTRATE.item("summon_wand", p -> new DispenseWand(p.stacksTo(1), null))
					.model((ctx, pvd) -> pvd.handheld(ctx)).defaultLang().tag(MGTagGen.GOLEM_INTERACT).register();
			RIDER_WAND = REGISTRATE.item("rider_wand", p -> new RiderWandItem(p.stacksTo(1), null))
					.model((ctx, pvd) -> pvd.handheld(ctx)).defaultLang().tag(MGTagGen.GOLEM_INTERACT).register();
			SQUAD_WAND = REGISTRATE.item("squad_wand", p -> new SquadWandItem(p.stacksTo(1), null))
					.model((ctx, pvd) -> pvd.handheld(ctx)).defaultLang().tag(MGTagGen.GOLEM_INTERACT).register();


			OMNI_COMMAND = REGISTRATE.item("omnipotent_wand_command", p -> new CommandWandItem(p.stacksTo(1), COMMAND_WAND))
					.model((ctx, pvd) -> pvd.handheld(ctx, pvd.modLoc("item/omnipotent_wand")))
					.lang("Omnipotent Wand: Command").tag(MGTagGen.GOLEM_OMNI_WAND)
					.register();
			OMNI_RETRIVAL = REGISTRATE.item("omnipotent_wand_retrieval", p -> new RetrievalWandItem(p.stacksTo(1), RETRIEVAL_WAND))
					.model((ctx, pvd) -> pvd.handheld(ctx, pvd.modLoc("item/omnipotent_wand")))
					.lang("Omnipotent Wand: Retrieval").tag(MGTagGen.GOLEM_OMNI_WAND)
					.removeTab(ITEMS.getKey()).register();
			OMNI_DISPENSE = REGISTRATE.item("omnipotent_wand_summon", p -> new DispenseWand(p.stacksTo(1), DISPENSE_WAND))
					.model((ctx, pvd) -> pvd.handheld(ctx, pvd.modLoc("item/omnipotent_wand")))
					.lang("Omnipotent Wand: Summon").tag(MGTagGen.GOLEM_OMNI_WAND)
					.removeTab(ITEMS.getKey()).register();
			OMNI_RIDER = REGISTRATE.item("omnipotent_wand_rider", p -> new RiderWandItem(p.stacksTo(1), RIDER_WAND))
					.model((ctx, pvd) -> pvd.handheld(ctx, pvd.modLoc("item/omnipotent_wand")))
					.lang("Omnipotent Wand: Rider").tag(MGTagGen.GOLEM_OMNI_WAND)
					.removeTab(ITEMS.getKey()).register();
			OMNI_SQUAD = REGISTRATE.item("omnipotent_wand_squad", p -> new SquadWandItem(p.stacksTo(1), SQUAD_WAND))
					.model((ctx, pvd) -> pvd.handheld(ctx, pvd.modLoc("item/omnipotent_wand")))
					.lang("Omnipotent Wand: Squad").tag(MGTagGen.GOLEM_OMNI_WAND)
					.removeTab(ITEMS.getKey()).register();

		}

		// golemguard armor
		{
			GOLEMGUARD_HELMET = REGISTRATE.item("roman_guard_helmet", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.HELMET, 8, 4, GolemModelPaths.HELMETS))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();
			GOLEMGUARD_CHESTPLATE = REGISTRATE.item("roman_guard_chestplate", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.CHESTPLATE, 10, 4, GolemModelPaths.CHESTPLATES))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();
			GOLEMGUARD_SHINGUARD = REGISTRATE.item("roman_guard_shinguard", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.LEGGINGS, 6, 4, GolemModelPaths.LEGGINGS))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();

			GOLEMGUARD_BOOTS = REGISTRATE.item("roman_guard_boots", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.BOOTS, 4, 4, GolemModelPaths.BOOTS_IRON))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();

			WINDSPIRIT_HELMET = REGISTRATE.item("wind_spirit_helmet", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.HELMET, 11, 6, GolemModelPaths.HELMETS))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();
			WINDSPIRIT_CHESTPLATE = REGISTRATE.item("wind_spirit_chestplate", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.CHESTPLATE, 14, 6, GolemModelPaths.CHESTPLATES))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();
			WINDSPIRIT_SHINGUARD = REGISTRATE.item("wind_spirit_shinguard", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.LEGGINGS, 8, 6, GolemModelPaths.LEGGINGS))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();
			WINDSPIRIT_BOOTS = REGISTRATE.item("wind_spirit_boots", p -> new MetalGolemArmorItem(p.stacksTo(1),
							ArmorItem.Type.BOOTS, 6, 6, GolemModelPaths.BOOTS_DIAMOND))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.defaultLang().register();

			BARBARICFLAMEVANGUARD_HELMET = REGISTRATE.item("barbaric_vanguard_helmet", p -> new MetalGolemArmorItem(p.stacksTo(1).fireResistant(),
							ArmorItem.Type.HELMET, 14, 8, 0.2F, GolemModelPaths.HELMETS))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).defaultLang().register();
			BARBARICFLAMEVANGUARD_CHESTPLATE = REGISTRATE.item("barbaric_vanguard_chestplate", p -> new MetalGolemArmorItem(p.stacksTo(1).fireResistant(),
							ArmorItem.Type.CHESTPLATE, 18, 8, 0.2F, GolemModelPaths.CHESTPLATES))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).defaultLang().register();
			BARBARICFLAMEVANGUARD_SHINGUARD = REGISTRATE.item("barbaric_vanguard_shinguard", p -> new MetalGolemArmorItem(p.stacksTo(1).fireResistant(),
							ArmorItem.Type.LEGGINGS, 10, 8, 0.2F, GolemModelPaths.LEGGINGS))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).defaultLang().register();
			BARBARICFLAMEVANGUARD_BOOTS = REGISTRATE.item("barbaric_vanguard_boots", p -> new NetheriteBootItem(p.stacksTo(1).fireResistant(),
							ArmorItem.Type.BOOTS, 10, 8, 0.2F, GolemModelPaths.BOOTS_NETHERITE))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).defaultLang().register();

			BEACON_BOOTS = REGISTRATE.item("beacon_boots",
							p -> new MetalGolemBeaconItem(p.stacksTo(1), 6, 6, GolemModelPaths.BOOTS_BEACON))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/beacon_boots")))
					.tag(MGTagGen.TOUGH_ITEM).register();

			DOG_ARMOR_IRON = regDogArmor("iron", ArmorMaterials.IRON, 16, 0).register();
			DOG_ARMOR_GOLD = regDogArmor("gold", ArmorMaterials.GOLD, 12, 0).register();
			DOG_ARMOR_DIAMOND = regDogArmor("diamond", ArmorMaterials.DIAMOND, 20, 8).register();
			DOG_ARMOR_NETHERITE = regDogArmor("netherite", ArmorMaterials.NETHERITE, 20, 12)
					.properties(p -> p.fireResistant().rarity(Rarity.EPIC))
					.tag(MGTagGen.TOUGH_ITEM).register();

		}

		//metalgolem weapon
		{
			METALGOLEM_WEAPON = GolemWeaponType.build(VanillaGolemWeaponMaterial.values());
			SLICING_AXE = SlicingAxe.buildItem("golem_slicing_axe", VanillaGolemWeaponMaterial.DIAMOND);
			IRON_BOW = REGISTRATE.item("iron_mecha_bow", p -> new MetalGolemBowItem(p, 15, 0))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.register();
			NETHERITE_BOW = REGISTRATE.item("netherite_mecha_bow", p -> new MetalGolemMechaBowItem(p, 30, 5))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).register();
			SONIC_CANNON = REGISTRATE.item("sonic_cannon", p -> new SonicCannonItem(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).register();
			BEACON_CANNON = REGISTRATE.item("beacon_cannon", p -> new BeaconCannonItem(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).register();
			FLAME_THROWER = REGISTRATE.item("flame_thrower", p -> new FlameThrowerItem(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/equipments/" + ctx.getName())))
					.tag(MGTagGen.TOUGH_ITEM).register();
		}

		// cards
		{
			CARD = new ItemEntry[16];
			for (int i = 0; i < 16; i++) {
				DyeColor color = DyeColor.byId(i);
				String name = color.getName();
				CARD[i] = REGISTRATE.item(name + "_config_card", p -> new ConfigCard(p.stacksTo(1), color))
						.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/card/" + name)))
						.tag(MGTagGen.CONFIG_CARD).defaultLang().register();
			}

			CARD_NAME = REGISTRATE.item("target_filter_name", p -> new NameFilterCard(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/card/name")))
					.tag(MGTagGen.GOLEM_INTERACT)
					.lang("Target Filter: Datapack").register();
			CARD_TYPE = REGISTRATE.item("target_filter_type", p -> new EntityTypeFilterCard(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/card/type")))
					.tag(MGTagGen.GOLEM_INTERACT)
					.lang("Target Filter: Entity Type").register();
			CARD_UUID = REGISTRATE.item("target_filter_uuid", p -> new UuidFilterCard(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/card/uuid")))
					.tag(MGTagGen.GOLEM_INTERACT)
					.lang("Target Filter: Entity UUID").register();
			CARD_DEF = REGISTRATE.item("target_filter_default", p -> new DefaultFilterCard(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/card/default")))
					.tag(MGTagGen.GOLEM_INTERACT)
					.lang("Target Filter: Default Target").register();
			CARD_PATH = REGISTRATE.item("patrol_path_recorder", p -> new PathRecordCard(p.stacksTo(1)))
					.model((ctx, pvd) -> pvd.generated(ctx, pvd.modLoc("item/card/path")))
					.tag(MGTagGen.GOLEM_INTERACT, MGTagGen.CURIO_PATH)
					.lang("Patrol Path Recorder").register();
		}

		// upgrades
		{
			EMPTY_UPGRADE = REGISTRATE.item("empty_upgrade", Item::new).defaultModel().defaultLang().tab(UPGRADES.getKey()).register();
			ADD_DIAMOND = REGISTRATE.item("diamond_expansion_template", p -> new AddSlotTemplate(p, GolemModifiers.DIAMOND_ADD)).defaultModel().defaultLang().tab(UPGRADES.getKey()).register();
			ADD_NETHERITE = REGISTRATE.item("netherite_expansion_template", p -> new AddSlotTemplate(p, GolemModifiers.NETHERITE_ADD)).defaultModel().defaultLang().tab(UPGRADES.getKey()).register();
			FIRE_IMMUNE = regUpgrade("fire_immune", () -> GolemModifiers.FIRE_IMMUNE).lang("Fire Immune Upgrade").register();
			THUNDER_IMMUNE = regUpgrade("thunder_immune", () -> GolemModifiers.THUNDER_IMMUNE).lang("Thunder Immune Upgrade").register();
			RECYCLE = regUpgrade("recycle", () -> GolemModifiers.RECYCLE).lang("Recycle Ugpgrade").register();
			DIAMOND = regUpgrade("diamond", () -> GolemModifiers.ARMOR).lang("Diamond Upgrade").register();
			NETHERITE = regUpgrade("netherite", () -> GolemModifiers.TOUGH).lang("Netherite Upgrade").register();
			QUARTZ = regUpgrade("quartz", () -> GolemModifiers.DAMAGE).lang("Quartz Upgrade").register();
			GOLD = regUpgrade("gold", () -> GolemModifiers.REGEN).lang("Golden Apple Upgrade").register();
			ENCHANTED_GOLD = regUpgrade("enchanted_gold", () -> GolemModifiers.REGEN, 2, true).lang("Enchanted Golden Apple Upgrade").register();
			FLOAT = regUpgrade("float", () -> GolemModifiers.FLOAT).lang("Float Upgrade").register();
			SPONGE = regUpgrade("sponge", () -> GolemModifiers.EXPLOSION_RES).lang("Sponge Upgrade").register();
			SWIM = regUpgrade("swim", () -> GolemModifiers.SWIM).lang("Swim Upgrade").register();
			PLAYER_IMMUNE = regUpgrade("player", () -> GolemModifiers.PLAYER_IMMUNE).lang("Player Immune Upgrade").register();
			ENDER_SIGHT = regUpgrade("ender_sight", () -> GolemModifiers.ENDER_SIGHT).lang("Ender Sight Upgrade").register();
			BELL = regUpgrade("bell", () -> GolemModifiers.BELL).lang("Bell Upgrade").register();
			SPEED = regUpgrade("speed", () -> GolemModifiers.SPEED).lang("Speed Upgrade").register();
			SLOW = regUpgrade("slow", () -> GolemModifiers.SLOW).lang("Potion Upgrade: Slowness").register();
			WEAK = regUpgrade("weak", () -> GolemModifiers.WEAK).lang("Potion Upgrade: Weakness").register();
			WITHER = regUpgrade("wither", () -> GolemModifiers.WITHER).lang("Potion Upgrade: Wither").register();
			EMERALD = regUpgrade("emerald", () -> GolemModifiers.EMERALD).lang("Emerald Upgrade").register();
			PICKUP = regUpgrade("pickup", () -> GolemModifiers.PICKUP).lang("Pickup Upgrade").register();
			PICKUP_MENDING = regUpgrade("pickup_mending", () -> GolemModifiers.PICKUP_MENDING).lang("Pickup Augment: Mending").register();
			PICKUP_NO_DESTROY = regUpgrade("pickup_no_destroy", () -> GolemModifiers.PICKUP_NODESTROY).lang("Pickup Augment: No Destroy").register();
			TALENTED = regUpgrade("talented", () -> GolemModifiers.TALENTED).lang("Meta Upgrade: Talented").register();
			CAULDRON = regUpgrade("cauldron", () -> GolemModifiers.CAULDRON).lang("Meta Upgrade: Cauldron").register();
			MOUNT_UPGRADE = regUpgrade("mount_upgrade", () -> GolemModifiers.MOUNT_UPGRADE).lang("Mount Upgrade").register();
			SIZE_UPGRADE = regUpgrade("size_upgrade", () -> GolemModifiers.SIZE_UPGRADE).lang("Size Upgrade").register();

		}
		CompatManager.register();

		GOLEMS = REGISTRATE.buildL2CreativeTab("golems", "Modular Golems - Golems", b -> b
				.icon(GolemItems.HOLDER_GOLEM::asStack));
		PARTS = REGISTRATE.buildL2CreativeTab("golems_parts", "Modular Golems - Parts", b -> b
				.icon(GolemItems.GOLEM_BODY::asStack));
		// buildL2CreativeTab 会把新建的 tab 设成 registrate 默认项，这里把 GOLEMS 设回去，
		// 否则之后注册的 holder 会被默认塞进 PARTS
		REGISTRATE.defaultCreativeTab(GOLEMS.getKey());

		// holders
		{
			HOLDER_GOLEM = REGISTRATE.item("metal_golem_holder", p ->
							new GolemHolder<>(p.fireResistant(), GolemTypes.TYPE_GOLEM))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.transform(e -> e.tab(GOLEMS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GOLEM_HOLDERS).defaultLang().register();

			HOLDER_HUMANOID = REGISTRATE.item("humanoid_golem_holder", p ->
							new GolemHolder<>(p.fireResistant(), GolemTypes.TYPE_HUMANOID))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.transform(e -> e.tab(GOLEMS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GOLEM_HOLDERS).defaultLang().register();

			HOLDER_DOG = REGISTRATE.item("dog_golem_holder", p ->
							new GolemHolder<>(p.fireResistant(), GolemTypes.TYPE_DOG))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.transform(e -> e.tab(GOLEMS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GOLEM_HOLDERS).defaultLang().register();
		}

		// 部件只显式进 ITEMS 和 PARTS，不能回落到 GOLEMS
		REGISTRATE.defaultCreativeTab(PARTS.getKey());

		// metal golem
		{
			GOLEM_BODY = REGISTRATE.item("metal_golem_body", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_GOLEM, MetalGolemPartType.BODY, 9))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
			GOLEM_ARM = REGISTRATE.item("metal_golem_arm", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_GOLEM, MetalGolemPartType.LEFT, 9))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
			GOLEM_LEGS = REGISTRATE.item("metal_golem_legs", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_GOLEM, MetalGolemPartType.LEG, 9))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
		}

		// humanoid golem
		{
			HUMANOID_BODY = REGISTRATE.item("humanoid_golem_body", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_HUMANOID, HumanoidGolemPartType.BODY, 6))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
			HUMANOID_ARMS = REGISTRATE.item("humanoid_golem_arms", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_HUMANOID, HumanoidGolemPartType.ARMS, 6))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
			HUMANOID_LEGS = REGISTRATE.item("humanoid_golem_legs", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_HUMANOID, HumanoidGolemPartType.LEGS, 6))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
		}

		// dog golem
		{
			DOG_BODY = REGISTRATE.item("dog_golem_body", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_DOG, DogGolemPartType.BODY, 6))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();

			DOG_LEGS = REGISTRATE.item("dog_golem_legs", p ->
							new GolemPart<>(p.fireResistant(), GolemTypes.TYPE_DOG, DogGolemPartType.LEGS, 3))
					.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
							.texture("particle", "minecraft:block/clay"))
					.tab(ITEMS.getKey())
					.transform(e -> e.tab(PARTS.getKey(), x -> e.getEntry().fillItemCategory(x)))
					.tag(MGTagGen.GENERIC_PARTS).defaultLang().register();
		}
		REGISTRATE.defaultCreativeTab(GOLEMS.getKey());

		FACADE = REGISTRATE.item("golem_facade", GolemFacade::new)
				.model((ctx, pvd) -> pvd.getBuilder(ctx.getName()).parent(new ModelFile.UncheckedModelFile("builtin/entity"))
						.texture("particle", "minecraft:block/clay").guiLight(BlockModel.GuiLight.FRONT))
				.removeTab(GOLEMS.getKey())
				.transform(e -> e.tab(ITEMS.getKey(), x -> e.getEntry().fillItemCategory(x)))
				.tag(MGTagGen.CURIO_SKIN).register();

		CompatManager.lateRegister();

		REGISTRATE.defaultCreativeTab(ITEMS.getKey());
		HOSTILE_WAND = REGISTRATE.item("hostile_wand", p -> new HostileWandItem(p.stacksTo(1)))
				.model((ctx, pvd) -> pvd.handheld(ctx)).defaultLang().tag(MGTagGen.GOLEM_INTERACT).register();

	}

	private static ItemBuilder<DogGolemArmorItem, L2Registrate> regDogArmor(String id, ArmorMaterial mat, int def, int tough) {
		return ModularGolems.REGISTRATE.item(id + "_dog_golem_armor", p -> new DogGolemArmorItem(
						p.stacksTo(1), mat, def, tough))
				.model((ctx, pvd) -> pvd.generated(ctx,
						pvd.modLoc("item/dog_armor/" + id + "_collar"),
						pvd.modLoc("item/dog_armor/" + id + "_wolf_armor")))
				.color(() -> () -> (s, i) -> i == 0 ? ((DogGolemArmorItem) s.getItem()).getColor(s) : -1);
	}

	public static ItemBuilder<SimpleUpgradeItem, L2Registrate> regModUpgrade(String id, Supplier<RegistryEntry<? extends GolemModifier>> mod, int lv, boolean foil, String modid) {
		var reg = regUpgradeImpl(id, mod, lv, foil, modid);
		reg.setData(ProviderType.ITEM_TAGS, (a, b) -> b.addTag(MGTagGen.GOLEM_UPGRADES).addOptional(reg.get().getId()));
		return reg;
	}

	public static ItemBuilder<SimpleUpgradeItem, L2Registrate> regModUpgrade(String id, Supplier<RegistryEntry<? extends GolemModifier>> mod, String modid) {
		return regModUpgrade(id, mod, 1, false, modid);
	}

	private static ItemBuilder<SimpleUpgradeItem, L2Registrate> regUpgrade(String id, Supplier<RegistryEntry<? extends GolemModifier>> mod) {
		return regUpgrade(id, mod, 1, false);
	}

	private static ItemBuilder<SimpleUpgradeItem, L2Registrate> regUpgrade(String id, Supplier<RegistryEntry<? extends GolemModifier>> mod, int level, boolean foil) {
		return regUpgradeImpl(id, mod, level, foil, ModularGolems.MODID).tag(MGTagGen.GOLEM_UPGRADES);
	}

	private static ItemBuilder<SimpleUpgradeItem, L2Registrate> regUpgradeImpl(String id, Supplier<RegistryEntry<? extends GolemModifier>> mod, int level, boolean foil, String modid) {
		return REGISTRATE.item(id, p -> new SimpleUpgradeItem(p, mod.get()::get, level, foil))
				.model((ctx, pvd) -> pvd.generated(ctx, new ResourceLocation(modid, "item/upgrades/" + id))
						.override().predicate(new ResourceLocation(ModularGolems.MODID, "blue_arrow"), 0.5f)
						.model(pvd.getBuilder(pvd.name(ctx) + "_purple")
								.parent(new ModelFile.UncheckedModelFile("item/generated"))
								.texture("layer0", new ResourceLocation(modid, "item/upgrades/" + id))
								.texture("layer1", new ResourceLocation(ModularGolems.MODID, "item/purple_arrow")))
						.end().override().predicate(new ResourceLocation(ModularGolems.MODID, "blue_arrow"), 1)
						.model(pvd.getBuilder(pvd.name(ctx) + "_blue")
								.parent(new ModelFile.UncheckedModelFile("item/generated"))
								.texture("layer0", new ResourceLocation(modid, "item/upgrades/" + id))
								.texture("layer1", new ResourceLocation(ModularGolems.MODID, "item/blue_arrow")))
						.end())
				.removeTab(ITEMS.getKey()).tab(UPGRADES.getKey());
	}

	private static ItemBuilder<SimpleUpgradeItem, L2Registrate> regUpgradeImpl(String id, NonNullFunction<Item.Properties, SimpleUpgradeItem> factory, String modid) {
		return REGISTRATE.item(id, factory)
				.model((ctx, pvd) -> pvd.generated(ctx, new ResourceLocation(modid, "item/upgrades/" + id))
						.override().predicate(new ResourceLocation(ModularGolems.MODID, "blue_arrow"), 0.5f)
						.model(pvd.getBuilder(pvd.name(ctx) + "_purple")
								.parent(new ModelFile.UncheckedModelFile("item/generated"))
								.texture("layer0", new ResourceLocation(modid, "item/upgrades/" + id))
								.texture("layer1", new ResourceLocation(ModularGolems.MODID, "item/purple_arrow")))
						.end().override().predicate(new ResourceLocation(ModularGolems.MODID, "blue_arrow"), 1)
						.model(pvd.getBuilder(pvd.name(ctx) + "_blue")
								.parent(new ModelFile.UncheckedModelFile("item/generated"))
								.texture("layer0", new ResourceLocation(modid, "item/upgrades/" + id))
								.texture("layer1", new ResourceLocation(ModularGolems.MODID, "item/blue_arrow")))
						.end())
				.removeTab(ITEMS.getKey()).tab(UPGRADES.getKey());
	}

	public static ItemBuilder<SimpleUpgradeItem, L2Registrate> regMultiModUpgrade(String id, List<Supplier<RegistryEntry<? extends GolemModifier>>> mods, int lv, boolean foil, String modid) {
		var reg = regUpgradeImpl(id, p -> new SimpleUpgradeItem(p, mods.stream().map(m -> (Supplier<GolemModifier>) m.get()::get).toList(), lv, foil), modid);
		reg.setData(ProviderType.ITEM_TAGS, (a, b) -> b.addTag(MGTagGen.GOLEM_UPGRADES).addOptional(reg.get().getId()));
		return reg;
	}

	public static ItemBuilder<SimpleUpgradeItem, L2Registrate> regMultiModUpgrade(String id, List<Supplier<RegistryEntry<? extends GolemModifier>>> mods, String modid) {
		return regMultiModUpgrade(id, mods, 1, false, modid);
	}

	public static <T extends Item> ItemEntry<T> item(String modid, String id, NonNullFunction<Item.Properties, T> func) {
		return REGISTRATE.item(id, func)
				.model((ctx, pvd) -> pvd.generated(ctx, new ResourceLocation(modid, "item/" + id)))
				.register();
	}

	public static void register() {
	}

}
