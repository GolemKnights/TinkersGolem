package dev.xkmc.modulargolems.init.data;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.IConfigSpec;
import net.minecraftforge.fml.config.ModConfig;
import org.apache.commons.lang3.tuple.Pair;

public class MGConfig {

	public static class Client {

		public final ForgeConfigSpec.ConfigValue<String> editorSavePath;
		public final ForgeConfigSpec.BooleanValue shieldUsePoseFixForModdedShields;

		Client(ForgeConfigSpec.Builder builder) {
			editorSavePath = builder.comment("Save path override for the in-game editor.",
							"Leave empty to save into the current world's datapacks folder.",
							"Set to an absolute path of a datapacks folder (the folder containing datapack pack folders)",
							"to save into a global datapack loader location instead, e.g. the folder used by",
							"OpenLoader's 'datapacks' or a modpack's global data folder.")
					.define("editorSavePath", "");
			shieldUsePoseFixForModdedShields = builder
					.comment("Replace isUsingItem with isBlocking for modded shield model predicate")
					.comment("Fix shield rendering on humanoid golem but may break stuff")
					.define("shieldUsePoseFixForModdedShields", false);
		}

	}

	public static class Common {

		public final ForgeConfigSpec.DoubleValue thorn;
		public final ForgeConfigSpec.DoubleValue fieryDamageFactor;
		public final ForgeConfigSpec.DoubleValue magicResistance;
		public final ForgeConfigSpec.DoubleValue explosionResistance;
		public final ForgeConfigSpec.DoubleValue compatTFHealing;
		public final ForgeConfigSpec.DoubleValue compatTFDamage;
		public final ForgeConfigSpec.IntValue manaMendingCost;
		public final ForgeConfigSpec.DoubleValue manaMendingVal;
		public final ForgeConfigSpec.DoubleValue manaBoostingDamage;
		public final ForgeConfigSpec.IntValue manaBoostingCost;
		public final ForgeConfigSpec.IntValue manaProductionVal;
		public final ForgeConfigSpec.DoubleValue manaBurstDamage;
		public final ForgeConfigSpec.IntValue manaBurstCost;
		public final ForgeConfigSpec.DoubleValue pixieAttackProb;
		public final ForgeConfigSpec.DoubleValue pixieCounterattackProb;
		public final ForgeConfigSpec.IntValue carminiteTime;
		public final ForgeConfigSpec.DoubleValue coating;
		public final ForgeConfigSpec.DoubleValue mechSpeed;
		public final ForgeConfigSpec.DoubleValue mechAttack;
		public final ForgeConfigSpec.IntValue mechMaxFuel;
		public final ForgeConfigSpec.BooleanValue barehandRetrieve;
		public final ForgeConfigSpec.BooleanValue strictInteract;
		public final ForgeConfigSpec.DoubleValue damageCap;
		public final ForgeConfigSpec.IntValue conduitCooldown;
		public final ForgeConfigSpec.IntValue conduitDamage;
		public final ForgeConfigSpec.DoubleValue conduitBoostAttack;
		public final ForgeConfigSpec.IntValue conduitBoostArmor;
		public final ForgeConfigSpec.IntValue conduitBoostToughness;
		public final ForgeConfigSpec.DoubleValue conduitBoostReduction;
		public final ForgeConfigSpec.DoubleValue conduitBoostSpeed;
		public final ForgeConfigSpec.IntValue thunderHeal;
		public final ForgeConfigSpec.IntValue teleportRadius;
		public final ForgeConfigSpec.IntValue teleportCooldown;
		public final ForgeConfigSpec.DoubleValue targetDamageBonus;
		public final ForgeConfigSpec.IntValue basePickupRange;
		public final ForgeConfigSpec.IntValue mendingXpCost;
		public final ForgeConfigSpec.DoubleValue armorBypassChance;
		public final ForgeConfigSpec.DoubleValue slicingDropUpgradeChance;
		public final ForgeConfigSpec.DoubleValue beaconCannonDamageFactor;
		public final ForgeConfigSpec.DoubleValue sonicCannonDamageFactor;
		public final ForgeConfigSpec.DoubleValue sonicCannonResonanceBonus;
		public final ForgeConfigSpec.DoubleValue mechanicalArmSpeed;
		public final ForgeConfigSpec.DoubleValue mechanicalArmPowerBonus;
		public final ForgeConfigSpec.DoubleValue mechanicalArmMiscBonusFactor;

		public final ForgeConfigSpec.IntValue summonDistance;
		public final ForgeConfigSpec.IntValue retrieveDistance;
		public final ForgeConfigSpec.IntValue retrieveRange;
		public final ForgeConfigSpec.BooleanValue ownerPickupOnly;
		public final ForgeConfigSpec.BooleanValue allowEditCuriosForOthers;
		public final ForgeConfigSpec.DoubleValue startFollowRadius;
		public final ForgeConfigSpec.DoubleValue stopWanderRadius;
		public final ForgeConfigSpec.DoubleValue maxWanderRadius;
		public final ForgeConfigSpec.DoubleValue riddenSpeedFactor;
		public final ForgeConfigSpec.BooleanValue sendForceRemovalMessage;
		public final ForgeConfigSpec.DoubleValue golemSoundVolumeFactor;
		public final ForgeConfigSpec.DoubleValue hostileGolemSoundVolumeFactor;

		public final ForgeConfigSpec.IntValue targetResetTime;
		public final ForgeConfigSpec.DoubleValue targetResetNoMovementRange;

		public final ForgeConfigSpec.IntValue dogGolemSlot;
		public final ForgeConfigSpec.IntValue humanoidGolemSlot;
		public final ForgeConfigSpec.IntValue largeGolemSlot;
		public final ForgeConfigSpec.BooleanValue doEnemyAggro;
		public final ForgeConfigSpec.BooleanValue allowDimensionChange;

		public final ForgeConfigSpec.DoubleValue candyDamage;
		public final ForgeConfigSpec.IntValue caramelDuration;
		public final ForgeConfigSpec.DoubleValue polarizeRange;
		public final ForgeConfigSpec.DoubleValue polarizeDamage;
		public final ForgeConfigSpec.DoubleValue polarizeForce;
		public final ForgeConfigSpec.DoubleValue reformationAbsorption;
		public final ForgeConfigSpec.DoubleValue reformationHealing;
		public final ForgeConfigSpec.IntValue reformationMax;
		public final ForgeConfigSpec.IntValue radiationDuration;
		public final ForgeConfigSpec.DoubleValue radiationDamage;
		public final ForgeConfigSpec.DoubleValue atomicHeal;
		public final ForgeConfigSpec.IntValue atomicDuration;
		public final ForgeConfigSpec.DoubleValue atomicBeamDamage;
		public final ForgeConfigSpec.DoubleValue atomicBeamRadius;
		public final ForgeConfigSpec.DoubleValue atomicBeamRange;
		public final ForgeConfigSpec.DoubleValue atomicBeamForce;
		public final ForgeConfigSpec.IntValue atomicBeamDuration;
		public final ForgeConfigSpec.IntValue atomicBeamCooldown;

		public final ForgeConfigSpec.DoubleValue hauntedBaseChance;
		public final ForgeConfigSpec.IntValue soulHealingRate;
		public final ForgeConfigSpec.IntValue soulHealingCost;
		public final ForgeConfigSpec.DoubleValue soulHealingThreshold;
		public final ForgeConfigSpec.DoubleValue soulHealingArmorBonus;
		public final ForgeConfigSpec.BooleanValue bossBreakShield;

		public final ForgeConfigSpec.DoubleValue ignitiumHealRate;
		public final ForgeConfigSpec.DoubleValue ignisSkillDamageFactor;
		public final ForgeConfigSpec.DoubleValue fireballArmorBonus;
		public final ForgeConfigSpec.DoubleValue flameStrikeArmorBonus;
		public final ForgeConfigSpec.DoubleValue laserArmorBonus;
		public final ForgeConfigSpec.DoubleValue missileArmorBonus;
		public final ForgeConfigSpec.DoubleValue earthquakeArmorBonus;
		public final ForgeConfigSpec.DoubleValue chargeArmorBonus;
		public final ForgeConfigSpec.DoubleValue monstrosityChargeBonus;
		public final ForgeConfigSpec.DoubleValue sandCurseBonus;
		public final ForgeConfigSpec.IntValue maledictusReviveCD;
		public final ForgeConfigSpec.IntValue maledictusReviveCDPartReduction;
		public final ForgeConfigSpec.DoubleValue maledictusRevivePHP;
		public final ForgeConfigSpec.DoubleValue maledictusRevivePHPPartBonus;

		public final ForgeConfigSpec.BooleanValue wandBypassConfig;

		public final ForgeConfigSpec.DoubleValue dungeonMeleeHealFactor;
		public final ForgeConfigSpec.DoubleValue dungeonLinkHealFactor;
		public final ForgeConfigSpec.IntValue obsidianDamageReduction;
		public final ForgeConfigSpec.DoubleValue primitiveHealthRatio;
		public final ForgeConfigSpec.DoubleValue primitiveDamageMultiplier;
		public final ForgeConfigSpec.IntValue resonanceAttackCooldown;
		public final ForgeConfigSpec.DoubleValue resonanceAttackDamageFactor;
		public final ForgeConfigSpec.IntValue resonanceAttackRange;
		public final ForgeConfigSpec.DoubleValue resonanceHealFactor;
		public final ForgeConfigSpec.IntValue resonanceHealRange;
		public final ForgeConfigSpec.IntValue ethertiteRepairDelay;

		Common(ForgeConfigSpec.Builder builder) {
			{
				barehandRetrieve = builder.comment("Allow players to retrieve the golems by bare hand")
						.define("barehandRetrieve", true);
				doEnemyAggro = builder.comment("Make mobs aggro to iron golem automatically aggro to modular golems")
						.define("doEnemyAggro", true);
				allowDimensionChange = builder.comment("Allow golems to enter portal")
						.define("allowDimensionChange", false);
				summonDistance = builder.comment("Max distance to summon single golem")
						.defineInRange("summonDistance", 64, 1, 1000);
				retrieveDistance = builder.comment("Max distance to retrieve single golem")
						.defineInRange("retrieveDistance", 64, 1, 1000);
				retrieveRange = builder.comment("Max distance to retrieve all golems")
						.defineInRange("retrieveRange", 20, 1, 1000);
				ownerPickupOnly = builder.comment("Only owner can pickup")
						.define("ownerPickupOnly", true);
				strictInteract = builder.comment("When enabled, the following features will be disabled when player holds item in hand:")
						.comment("- give item to golem or take items from golem by right click").comment("- order dog golem to seat")
						.define("strictInteract", false);
				wandBypassConfig = builder.comment("Wand interaction bypass config lock")
						.define("wandBypassConfig", false);
				allowEditCuriosForOthers = builder.comment("Allow command wand to edit curios of other mobs you own")
						.define("allowEditCuriosForOthers", true);
				startFollowRadius = builder.comment("Max golem activity radius before following player in follow mode")
						.defineInRange("startFollowRadius", 10d, 1, 100);
				stopWanderRadius = builder.comment("Max golem activity radius before willing to go back to origin in wander mode")
						.defineInRange("stopWanderRadius", 20d, 1, 100);
				maxWanderRadius = builder.comment("Max golem activity radius before being teleported back")
						.defineInRange("maxWanderRadius", 30d, 1, 100);
				riddenSpeedFactor = builder.comment("Speed factor for dog golem when ridden by entities")
						.defineInRange("riddenSpeedFactor", 0.8, 0, 2);
				targetResetTime = builder.comment("Target reset time after no movement, in ticks")
						.defineInRange("targetResetTime", 600, 1, 10000);
				targetResetNoMovementRange = builder.comment("Distance considered as no movement")
						.defineInRange("targetResetNoMovementRange", 0.5, 0, 10);
				sendForceRemovalMessage = builder.comment("Send force removal message")
						.define("sendForceRemovalMessage", true);
				bossBreakShield = builder.comment("All blockable boss attacks will be able to break shields")
						.define("bossBreakShield", true);
				slicingDropUpgradeChance = builder.comment("Chance for each upgrade to drop when killed by Slicing Axe")
						.defineInRange("slicingDropUpgradeChance", 0.5, 0, 1);
				beaconCannonDamageFactor = builder.comment("Damage of Beacon Cannon as percentage of golem melee damage")
						.defineInRange("beaconCannonDamageFactor", 0.5, 0, 1);
				sonicCannonDamageFactor = builder.comment("Damage of Sonic Cannon as percentage of golem melee damage")
						.defineInRange("sonicCannonDamageFactor", 0.25, 0, 1);
				sonicCannonResonanceBonus = builder.comment("Bonus damage of Sonic Cannon per sculk part, as percentage of golem melee damage")
						.defineInRange("sonicCannonResonanceBonus", 0.1, 0, 1);


				largeGolemSlot = builder.comment("Default slots for large golem")
						.defineInRange("largeGolemSlot", 4, 0, 100);
				humanoidGolemSlot = builder.comment("Default slots for humanoid golem")
						.defineInRange("humanoidGolemSlot", 3, 0, 100);
				dogGolemSlot = builder.comment("Default slots for dog golem")
						.defineInRange("dogGolemSlot", 2, 0, 100);
				golemSoundVolumeFactor = builder.comment("Player golem sound factor")
						.defineInRange("golemSoundVolumeFactor", 1d, 0, 2);
				hostileGolemSoundVolumeFactor = builder.comment("Hostile golem sound factor")
						.defineInRange("hostileGolemSoundVolumeFactor", 1d, 0, 2);
			}

			// modifiers
			{
				builder.push("modifiers");
				{
					thorn = builder.comment("Percentage damage reflection per level of thorn")
							.defineInRange("thorn", 0.2, 0, 100);
					magicResistance = builder.comment("Percentage damage reduction per level of magic resistance")
							.defineInRange("magicResistance", 0.2, 0, 1);
					explosionResistance = builder.comment("Percentage damage reduction per level of explosion resistance")
							.defineInRange("explosionResistance", 0.2, 0, 1);
					damageCap = builder.comment("Damage Cap at max level")
							.defineInRange("damageCap", 0.1d, 0, 1);
					thunderHeal = builder.comment("Healing when thunder immune golems are striked")
							.defineInRange("thunderHeal", 10, 1, 10000);
					armorBypassChance = builder.comment("Armor Penetration modifier: chance for damage to bypass armor per level")
							.defineInRange("armorBypassChance", 0.2, 0, 1);
				}
				builder.pop();

				builder.push("twilight forest compat");
				{
					fieryDamageFactor = builder.comment("Percentage damage addition per level of fiery")
							.defineInRange("fieryDamageFactor", 0.25, 0, 100);
					compatTFHealing = builder.comment("Percentage healing bonus per level of twilight healing")
							.defineInRange("compatTFHealing", 0.5, 0, 100);
					compatTFDamage = builder.comment("Percentage damage bonus per level of twilight damage")
							.defineInRange("compatTFDamage", 0.2, 0, 100);
					carminiteTime = builder.comment("Time for the golem to be invincible (in ticks) per level of carminite")
							.defineInRange("carminiteTime", 20, 1, 100000);
				}
				builder.pop();

				builder.push("botania compat");
				{
					manaMendingCost = builder.comment("Mana mending cost per HP")
							.defineInRange("mendingManaCost", 200, 1, 50000);
					manaMendingVal = builder.comment("Mana mending value per level")
							.defineInRange("manaMendingVal", 4D, 0.1D, 100D);
					manaBoostingDamage = builder.comment("Percentage damage bonus per level of mana boost")
							.defineInRange("manaBoostingDamage", 0.2, 0, 100);
					manaBoostingCost = builder.comment("Mana boosting cost per level (of 1 hit)")
							.defineInRange("manaBoostingCost", 500, 0, 100000);
					manaProductionVal = builder.comment("Mana production value per level")
							.defineInRange("manaProductionVal", 20, 0, 100000);
					manaBurstDamage = builder.comment("Damage of magic burst as percentage of attack damage")
							.defineInRange("manaBurstDamage", 0.25, 0, 1.0);
					manaBurstCost = builder.comment("Mana burst cost per level")
							.defineInRange("manaBurstCost", 2000, 0, 100000);
					pixieAttackProb = builder.comment("Probability of summoning a pixie when attacking")
							.defineInRange("pixieAttackProb", 0.05, 0, 1.0);
					pixieCounterattackProb = builder.comment("Probability of summoning a pixie when attacked")
							.defineInRange("pixiecounterattackProb", 0.25, 0, 1.0);
				}
				builder.pop();

				builder.push("create compat");
				{
					coating = builder.comment("Damage absorbed per level of coating")
							.defineInRange("coating", 1d, 0, 10000);
					mechSpeed = builder.comment("Speed boost per level of Mechanical Mobility")
							.defineInRange("mechSpeed", 0.2, 0, 1);
					mechAttack = builder.comment("Attack boost per level of Mechanical Force")
							.defineInRange("mechAttack", 0.2, 0, 1);
					mechMaxFuel = builder.comment("Maximum number of fuel item that can be added at the same time")
							.defineInRange("mechMaxFuel", 3, 1, 364);
					mechanicalArmSpeed = builder.comment("Mechanical Arm: default movement speed")
							.comment("Animation at speed of 1 is 5 seconds. At speed of 0.5, it takes the arm 10 seconds to perform a fix.")
							.defineInRange("mechanicalArmSpeed", 0.5, 0.1, 4);
					mechanicalArmPowerBonus = builder.comment("Mechanical Arm: bonus speed when golem is fueled up")
							.comment("At default speed of 0.5 and bonus of 1, golems fix itself 3 times faster when powered.")
							.defineInRange("mechanicalArmPowerBonus", 1d, 0, 4);
					mechanicalArmMiscBonusFactor = builder.comment("Mechanical Arm: bonus speed factor for other create golem effects")
							.comment("- Mechanical Engine Modifier: +0.2, making Create golem fix itself faster than other golems even when unpowered.")
							.comment("- Mechanical Mobility Effect: +0.2 per level, effectively another power bonus")
							.comment("- Mechanical Force Effect: +0.1 per level, effectively another power bonus")
							.comment("This config value puts a factor on above bonuses.")
							.defineInRange("mechanicalArmMiscBonusFactor", 1d, 0, 10);
				}
				builder.pop();

				builder.push("l2complements compat");
				{
					conduitCooldown = builder.comment("Conduit cooldown")
							.defineInRange("conduitCooldown", 120, 0, 10000);
					conduitDamage = builder.comment("Conduit damage")
							.defineInRange("conduitDamage", 2, 0, 10000);
					conduitBoostAttack = builder.comment("Conduit modifier boosts attack (percentage) when golem is in water")
							.defineInRange("conduitBoostAttack", 0.2, 0, 100);
					conduitBoostArmor = builder.comment("Conduit modifier boosts armor when golem is in water")
							.defineInRange("conduitBoostArmor", 5, 0, 100);
					conduitBoostToughness = builder.comment("Conduit modifier boosts toughness when golem is in water")
							.defineInRange("conduitBoostToughness", 2, 0, 100);
					conduitBoostSpeed = builder.comment("Conduit modifier boosts speed (percentage) when golem is in water")
							.defineInRange("conduitBoostSpeed", 0.2, 0, 100);
					conduitBoostReduction = builder.comment("Conduit modifier reduce damage taken when golem is in water (multiplicative)")
							.defineInRange("conduitBoostReduction", 0.2, 0, 100);
					teleportRadius = builder.comment("Teleport max radius")
							.defineInRange("teleportRadius", 6, 1, 32);
					teleportCooldown = builder.comment("Teleport cooldown in ticks for avoiding physical damage")
							.defineInRange("teleportCooldown", 40, 1, 10000);
					targetDamageBonus = builder.comment("Damage bonus for attacking specific type of enemy")
							.defineInRange("targetDamageBonus", 0.5, 0, 100);
					basePickupRange = builder.comment("Pickup range per level for pickup upgrade")
							.defineInRange("basePickupRange", 6, 1, 16);
					mendingXpCost = builder.comment("Mending Xp Cost per health point")
							.defineInRange("mendingXpCost", 2, 1, 10000);
				}
				builder.pop();

				builder.push("alexscaves compat");
				{
					candyDamage = builder.comment("Gum ball damage")
							.defineInRange("candyDamage", 4d, 1, 100);
					caramelDuration = builder.comment("Molten caramel duration in ticks")
							.defineInRange("caramelDuration", 200, 1, 10000);
					polarizeRange = builder.comment("Polarize modifier pull/push base radius")
							.defineInRange("polarizeRange", 5d, 1, 40);
					polarizeDamage = builder.comment("Polarize modifier base damage")
							.defineInRange("polarizeDamage", 2d, 0, 100);
					polarizeForce = builder.comment("Polarize modifier pull/push force")
							.defineInRange("polarizeForce", 0.1d, 0, 1);
					reformationAbsorption = builder.comment("Reformation modifier absorption per iron ingot")
							.defineInRange("reformationAbsorption", 10d, 1, 100);
					reformationHealing = builder.comment("Reformation modifier healing per iron ingot")
							.defineInRange("reformationHealing", 2d, 0, 100);
					reformationMax = builder.comment("Reformation modifier max stacking per level")
							.defineInRange("reformationMax", 2, 1, 10);
					radiationDuration = builder.comment("Radiation modifier: duration of irradiated effect")
							.defineInRange("radiationDuration", 200, 20, 20000);
					radiationDamage = builder.comment("Radiation modifier: damage boost per irradiated level")
							.defineInRange("radiationDamage", 0.2, 0, 1);
					atomicHeal = builder.comment("Atomic Fueling modifier: percent healing per uranium nugget per level")
							.defineInRange("atomicHeal", 0.1, 0, 1);
					atomicDuration = builder.comment("Atomic Fueling modifier: boost duration per uranium nugget used")
							.defineInRange("atomicDuration", 200, 20, 20000);
		atomicBeamDamage = builder.comment("Atomic Breath modifier: base damage of each beam hit")
				.defineInRange("atomicBeamDamage", 20d, 0, 200);
		atomicBeamRadius = builder.comment("Atomic Breath modifier: base radius of each beam hit")
				.defineInRange("atomicBeamRadius", 6d, 0.5, 32);
		atomicBeamRange = builder.comment("Atomic Breath modifier: how far the beam reaches")
				.defineInRange("atomicBeamRange", 100d, 1, 256);
		atomicBeamForce = builder.comment("Atomic Breath modifier: base knockback of each beam hit")
				.defineInRange("atomicBeamForce", 1d, 0, 10);
		atomicBeamDuration = builder.comment("Atomic Breath modifier: beam duration in ticks")
				.defineInRange("atomicBeamDuration", 200, 1, 20000);
		atomicBeamCooldown = builder.comment("Atomic Breath modifier: cooldown in ticks between beams")
				.defineInRange("atomicBeamCooldown", 500, 0, 20000);

				}
				builder.pop();

				builder.push("goety compat");
				{
					hauntedBaseChance = builder.comment("Chance per armor per modifier level to summon haunted armor servant")
							.defineInRange("hauntedBaseChance", 0, 0.05, 1);
					soulHealingCost = builder.comment("Soul Repair modifier healing soul cost as multiple of item repair soul cost")
							.defineInRange("soulHealingCost", 2, 1, 100);
					soulHealingRate = builder.comment("Soul Repair modifier healing rate per second")
							.defineInRange("soulHealingRate", 2, 1, 100);
					soulHealingThreshold = builder.comment("Soul Repair modifier healing only when golem health is below this percentage")
							.defineInRange("soulHealingThreshold", 0.75, 0, 1);
					soulHealingArmorBonus = builder.comment("Soul Repair bonus on armor items")
							.defineInRange("soulHealingArmorBonus", 0.5, 0, 10);
				}
				builder.pop();

				builder.push("cataclysm compat");
				{
					ignitiumHealRate = builder.comment("Heal rate as percentage of damage dealt per level of blazing brand")
							.defineInRange("ignitiumHealRate", 0.1d, 0, 10);
					ignisSkillDamageFactor = builder.comment("Ignitium golem skill damage factor")
							.defineInRange("ignisSkillDamageFactor", 0.5d, 0, 1);
					fireballArmorBonus = builder.comment("Ignis Helmet Bonus: Fireball damage boost")
							.defineInRange("fireballArmorBonus", 0.5, 0, 10);
					flameStrikeArmorBonus = builder.comment("Ignis Shinguard Bonus: Flame Strike damage boost")
							.defineInRange("flameStrikeArmorBonus", 0.5, 0, 10);
					laserArmorBonus = builder.comment("Harbinger Helmet Bonus: Death Laser damage boost")
							.defineInRange("laserArmorBonus", 1d, 0, 10);
					missileArmorBonus = builder.comment("Harbinger Chestplate Bonus: Homing Missile damage boost")
							.defineInRange("missileArmorBonus", 1d, 0, 10);
					earthquakeArmorBonus = builder.comment("Monstrosity Armor Bonus: Monstrosity Earthquake Modifier damage boost")
							.defineInRange("earthquakeArmorBonus", 0.5d, 0, 10);
					chargeArmorBonus = builder.comment("Harbinger Shinguard Bonus: Harbinger Charge damage boost")
							.defineInRange("chargeArmorBonus", 1d, 0, 10);
					monstrosityChargeBonus = builder.comment("Monstrosity Chestplate Bonus: charge damage boost for all charge skills")
							.defineInRange("monstrosityChargeBonus", 0.5d, 0, 10);
					sandCurseBonus = builder.comment("Sandstorm Upgrade damage bonus per level")
							.defineInRange("sandCurseBonus", 0.1d, 0, 10);
					maledictusReviveCD = builder.comment("Cursium Golem Chestplate: Revive Cooldown")
							.defineInRange("maledictusReviveCD", 360, 10, 10000);
					maledictusReviveCDPartReduction = builder.comment("Cursium Golem Chestplate: Cursium Part/Armor reduction on revive cooldown")
							.defineInRange("maledictusReviveCDPartReduction", 30, 10, 10000);
					maledictusRevivePHP = builder.comment("Cursium Golem Chestplate: Revived health percentage")
							.defineInRange("maledictusRevivePHP", 0.25, 0.01, 1);
					maledictusRevivePHPPartBonus = builder.comment("Cursium Golem Chestplate: Cursium Part/Armor bonus on revived health")
							.defineInRange("maledictusRevivePHPPartBonus", 0.125, 0, 1);
				}
				builder.pop();

				builder.push("composite material compat");
				{
					dungeonMeleeHealFactor = builder.comment("Dungeon Absorption: lifesteal ratio for melee damage.")
							.defineInRange("dungeonMeleeHealFactor", 0.25, 0, 2);
					dungeonLinkHealFactor = builder.comment("Dungeon Link: lifesteal ratio for melee damage.")
							.defineInRange("dungeonLinkHealFactor", 0.2, 0, 1);
					obsidianDamageReduction = builder.comment("Obsidian: damage reduced.")
							.defineInRange("obsidianDamageReduction", 1, 0, 100);
					primitiveHealthRatio = builder.comment("Primitive Blast: health ratio")
							.defineInRange("primitiveHealthRatio", 0.05, 0, 1);
					primitiveDamageMultiplier = builder.comment("Primitive Curse: damage multiplier")
							.defineInRange("primitiveDamageMultiplier", 0.8, 0, 1);
					resonanceAttackCooldown = builder.comment("Resonant Attack: Cooldown")
							.defineInRange("resonanceAttackCooldown", 20, 1, 1000);
					resonanceAttackDamageFactor = builder.comment("Resonant Attack: damage factor")
							.defineInRange("resonanceAttackDamageFactor", 0.1, 0, 1);
					resonanceAttackRange = builder.comment("Resonant Attack: chain range")
							.defineInRange("resonanceAttackRange", 8, 0, 64);
					resonanceHealFactor = builder.comment("Resonant Heal: healing ratio")
							.defineInRange("resonanceHealFactor", 0.25, 0, 5);
					resonanceHealRange = builder.comment("Resonant Heal: chain range")
							.defineInRange("resonanceHealRange", 32, 0, 64);
					ethertiteRepairDelay = builder.comment("Etherite Plating: repair delay")
							.defineInRange("ethertiteRepairDelay", 600, 20, 1000);
				}
				builder.pop();
			}
		}

	}

	public static final ForgeConfigSpec CLIENT_SPEC;
	public static final Client CLIENT;

	public static final ForgeConfigSpec COMMON_SPEC;
	public static final Common COMMON;

	static {
		final Pair<Client, ForgeConfigSpec> client = new ForgeConfigSpec.Builder().configure(Client::new);
		CLIENT_SPEC = client.getRight();
		CLIENT = client.getLeft();

		final Pair<Common, ForgeConfigSpec> specPair = new ForgeConfigSpec.Builder().configure(Common::new);
		COMMON_SPEC = specPair.getRight();
		COMMON = specPair.getLeft();
	}

	public static void init() {
		register(ModConfig.Type.CLIENT, CLIENT_SPEC);
		register(ModConfig.Type.COMMON, COMMON_SPEC);
	}

	private static void register(ModConfig.Type type, IConfigSpec<?> spec) {
		var mod = ModLoadingContext.get().getActiveContainer();
		String path = "l2_configs/" + mod.getModId() + "-" + type.extension() + ".toml";
		ModLoadingContext.get().registerConfig(type, spec, path);
	}


}
