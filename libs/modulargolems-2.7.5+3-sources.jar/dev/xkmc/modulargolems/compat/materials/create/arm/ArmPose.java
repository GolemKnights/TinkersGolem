package dev.xkmc.modulargolems.compat.materials.create.arm;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.xkmc.modulargolems.content.client.pose.GolemShoulderPose;
import dev.xkmc.modulargolems.content.entity.common.AbstractGolemEntity;
import dev.xkmc.modulargolems.content.entity.common.IGolemModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

public class ArmPose implements GolemShoulderPose {

	@Override
	public void setup(AbstractGolemEntity<?, ?> entity, IGolemModel<?, ?, ?> model, ItemStack stack, int slot, float pTick) {

	}

	/**
	 * Mount point of the arm, in model pixels. The bipedal numbers are the metal golem shoulder; the
	 * dog golem mounts it flat on its back instead.
	 */
	private static final float BIPEDAL_X = 7f / 16f;
	private static final float BIPEDAL_Y = 31f / 16f;
	private static final float DOG_X = 6f / 16f;
	private static final float DOG_Y = 26f / 16f;
	private static final float DOG_Z = 0f / 16f;

	@Override
	public void render(AbstractGolemEntity<?, ?> entity, IGolemModel<?, ?, ?> model, ItemStack stack, int slot, PoseStack pose, MultiBufferSource source, int light, float pTick) {
		pose.pushPose();
		try {
			int s0 = slot < 0 ? -1 : 1;
			// slot zero is the center mount used by back carried weapons
			Vec3 src = slot == 0
					? new Vec3(DOG_X, DOG_Y, DOG_Z)
					: new Vec3(s0 * BIPEDAL_X, BIPEDAL_Y, 0);
			var def = ArmAngleTarget.NO_TARGET;
			ArmState state;
			var tag = stack.getOrCreateTag();
			long last = tag.getLong("FixAction");
			float speed = Mth.clamp(tag.getFloat("FixSpeed"), 0.25f, 4f);
			long current = entity.level().getGameTime();
			float time = ((current - last) + pTick) * speed;
			ItemStack repair = Items.IRON_INGOT.getDefaultInstance();
			if (tag.contains("DisplayItem", Tag.TAG_COMPOUND)) {
				repair = ItemStack.of(tag.getCompound("DisplayItem"));
			}
			if (last > current || time > 80) {
				state = new ArmState(entity.level(), ItemStack.EMPTY, 0, def, def);
			} else if (time < 40) {
				float progress = 1 - Math.abs(time / 20 - 1);
				var dst = new Vec3(0, 18 / 16f, 20 / 16f);
				var target = new ArmAngleTarget(src, dst, Direction.SOUTH, false);
				target.headAngle += 180;
				var diff = ArmState.getShortestAngleDiff(def.baseAngle, target.baseAngle);
				diff = diff > 0 ? diff - 360 : diff + 360;
				target.baseAngle = def.baseAngle + diff;
				ItemStack held = time > 20 ? repair : ItemStack.EMPTY;
				state = new ArmState(entity.level(), held, progress, def, target);
			} else {
				float progress = 1 - Math.abs((time - 40) / 20 - 1);
				var dst = new Vec3(0, 18 / 16f, -20 / 16f);
				var target = new ArmAngleTarget(src, dst, Direction.NORTH, false);
				target.headAngle += 180;
				var diff = ArmState.getShortestAngleDiff(def.baseAngle, target.baseAngle);
				target.baseAngle = def.baseAngle + diff;
				ItemStack held = time < 60 ? repair : ItemStack.EMPTY;
				state = new ArmState(entity.level(), held, progress, def, target);
			}

			pose.scale(-1, -1, 1);
			pose.translate(src.x - 0.5f, src.y - 2f, src.z - 8.5f / 16);

			ArmRenderer.render(state, pTick, pose, source, light, OverlayTexture.NO_OVERLAY);

		} catch (Throwable e) {

		}
		pose.popPose();
	}

}
