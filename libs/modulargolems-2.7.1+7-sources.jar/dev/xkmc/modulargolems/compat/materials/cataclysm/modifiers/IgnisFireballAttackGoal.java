package dev.xkmc.modulargolems.compat.materials.cataclysm.modifiers;

import dev.xkmc.modulargolems.content.entity.common.AbstractGolemEntity;
import dev.xkmc.modulargolems.content.modifier.special.BaseRangedAttackGoal;
import net.minecraft.world.entity.LivingEntity;

public class IgnisFireballAttackGoal extends BaseRangedAttackGoal {

	public IgnisFireballAttackGoal(AbstractGolemEntity<?, ?> golem, int lv) {
		super(200, 0, 25, golem, lv);
	}

	@Override
	protected boolean performAttack(LivingEntity target) {
		IgnisFireballModifier.addFireball(golem, lv);
		return true;
	}

}

