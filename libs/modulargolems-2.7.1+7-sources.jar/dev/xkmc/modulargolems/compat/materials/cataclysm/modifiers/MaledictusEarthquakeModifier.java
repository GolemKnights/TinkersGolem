package dev.xkmc.modulargolems.compat.materials.cataclysm.modifiers;

import dev.xkmc.cataclysm_mux.GolemCataProxy;
import dev.xkmc.cataclysm_mux.MWCataProxy;
import dev.xkmc.modulargolems.compat.materials.cataclysm.CataCompatRegistry;
import dev.xkmc.modulargolems.compat.materials.cataclysm.CataDispatch;
import dev.xkmc.modulargolems.content.core.StatFilterType;
import dev.xkmc.modulargolems.content.entity.common.AbstractGolemEntity;
import dev.xkmc.modulargolems.content.entity.common.GolemFlags;
import dev.xkmc.modulargolems.content.modifier.base.GolemModifier;
import dev.xkmc.modulargolems.content.modifier.special.EarthquakeHelper;
import dev.xkmc.modulargolems.util.GolemUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import java.util.function.Consumer;

public class MaledictusEarthquakeModifier extends GolemModifier implements EarthquakeHelper.Modifier {

	public MaledictusEarthquakeModifier() {
		super(StatFilterType.HEALTH, 1);
	}

	@Override
	public void onRegisterFlag(Consumer<GolemFlags> cons) {
		cons.accept(GolemFlags.EARTH_QUAKE);
	}

	@Override
	public void handleEvent(AbstractGolemEntity<?, ?> golem, int value, byte event) {
		if (event == EarthquakeHelper.FLAG) {
			EarthquakeHelper.makeParticles(golem, 0, 0);
		}
	}

	@Override
	public int getCoolDown(AbstractGolemEntity<?, ?> golem, int lv) {
		int cd = EarthquakeHelper.Modifier.super.getCoolDown(golem, lv);
		if (golem.getItemBySlot(EquipmentSlot.LEGS).is(CataCompatRegistry.MALEDICTUS_SHINGUARD.get()))
			cd /= 2;
		return cd;
	}

	@Override
	public void onAttackTarget(AbstractGolemEntity<?, ?> entity, LivingAttackEvent event, int level) {
		var source = event.getSource();
		var direct = source.getDirectEntity();
		if (direct != null && direct.getType().builtInRegistryHolder().unwrapKey().orElseThrow().location()
				.equals(new ResourceLocation(CataDispatch.MODID, "phantom_halberd"))) {
			if (entity.getItemBySlot(EquipmentSlot.HEAD).is(CataCompatRegistry.MALEDICTUS_HELMET.get())) {
				event.getEntity().invulnerableTime = 0;
			}
		}
	}

	@Override
	public void performEarthQuake(AbstractGolemEntity<?, ?> golem, int level) {
		golem.playSound(SoundEvents.GENERIC_EXPLODE, 1.5F, 1.0F + golem.getRandom().nextFloat() * 0.1F);
		for (LivingEntity entity : golem.level().getEntitiesOfClass(LivingEntity.class, golem.getBoundingBox().inflate(7.0))) {
			if (!golem.isAlliedTo(entity) && entity != golem) {
				float damage = GolemUtils.adjustedDamage(
						(float) golem.getAttributeValue(Attributes.ATTACK_DAMAGE),
						entity.getMaxHealth() * GolemCataProxy.maledictusEarthquakeDamage()
				);
				boolean flag = entity.hurt(golem.damageSources().mobAttack(golem), damage);
				if (flag) {
					EarthquakeHelper.launch(golem, entity, 0.5f);
				}
			}
		}
		MWCataProxy.spawnHalberd(golem);
	}

}
